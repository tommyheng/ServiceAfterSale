﻿CREATE TABLE [dbo].[RoleFunctionMap]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [RoleId] INT NOT NULL, 
    [FunctionId] INT NOT NULL
)
