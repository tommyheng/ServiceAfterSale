﻿-- 快递公司表
CREATE TABLE [dbo].[Express]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Name] NVARCHAR(50) NOT NULL
)
